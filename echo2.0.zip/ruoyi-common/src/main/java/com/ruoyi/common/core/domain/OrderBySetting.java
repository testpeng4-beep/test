package com.ruoyi.common.core.domain;

public class OrderBySetting {
    public static String value = "";
}
