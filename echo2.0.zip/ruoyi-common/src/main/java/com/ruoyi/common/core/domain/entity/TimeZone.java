package com.ruoyi.common.core.domain.entity;

import lombok.Data;

/**
 * @author:michael
 * @createDate: 2022/9/19 16:48
 */
@Data
public class TimeZone {
    private String zoneId;

    private String offSet;

    private String offSetValue;

}
