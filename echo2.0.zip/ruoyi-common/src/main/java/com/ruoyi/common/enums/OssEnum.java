package com.ruoyi.common.enums;

/**
 * OssEnum
 *
 * @author Chopper
 * @version v1.0
 * 2022-06-06 11:23
 */
public enum OssEnum {
    /**
     *
     */
    ALI_OSS, MINIO
}
