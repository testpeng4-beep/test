
package com.ruoyi.common.trc;

import lombok.Data;

@Data
public class TRC {
    private boolean confirmed;
    private String contractRet;
}
