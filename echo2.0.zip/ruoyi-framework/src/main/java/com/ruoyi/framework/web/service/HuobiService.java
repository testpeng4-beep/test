package com.ruoyi.framework.web.service;

import com.alibaba.fastjson2.JSONObject;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.framework.web.domain.KlineParamVO;
import org.jvnet.hk2.annotations.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class HuobiService {

}
