package com.ruoyi.quartz.task;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ruoyi.bussiness.domain.*;
import com.ruoyi.bussiness.domain.setting.AddMosaicSetting;
import com.ruoyi.bussiness.domain.setting.Setting;
import com.ruoyi.bussiness.service.*;
import com.ruoyi.common.core.redis.RedisCache;
import com.ruoyi.common.enums.*;
import com.ruoyi.common.utils.RedisUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 秒合约结算
 */
@RequiredArgsConstructor
@Slf4j
@Component("secondContractTask")
public class SecondContractTask {

    @Resource
    private ITSecondContractOrderService secondContractOrderService;
    @Resource
    private RedisCache redisCache;
    @Resource
    private ITAppAssetService assetService;
    @Resource
    private ITAppWalletRecordService appWalletRecordService;
    @Resource
    private ITAppUserService appUserService;
    @Resource
    private ITAppUserDetailService appUserDetailService;
    @Resource
    private ITSecondCoinConfigService secondCoinConfigService;
    @Resource
    private SettingService settingService;
    @Resource
    private RedisUtil redisUtil;
    @Value("${api-redis-stream.names}")
    private String redisStreamNames;

    /**
     * 定时任务：结算所有到期的秒合约订单
     */
    public void secondContract() {
        try {
            List<TSecondContractOrder> list = secondContractOrderService.list(
                    new LambdaQueryWrapper<TSecondContractOrder>()
                            .eq(TSecondContractOrder::getStatus, "0")
                            .lt(TSecondContractOrder::getCloseTime, new Date().getTime())
            );
            for (TSecondContractOrder order : list) {
                TAppUser tAppUser = appUserService.selectTAppUserByUserId(order.getUserId());
                settlement(order, tAppUser);
            }
        } catch (Exception e) {
            log.error("秒合约结算异常: ", e);
        }
    }

    /**
     * 结算单个订单
     */
    private void settlement(TSecondContractOrder order, TAppUser tAppUser) {
        try {
            // 设置开奖结果: 赢 1, 输 2, 平 3
            String openResult = "1";
            BigDecimal returnAmount = BigDecimal.ZERO;
            BigDecimal betAmount = order.getBetAmount();
            Integer type = Integer.parseInt(order.getBetContent()); // 1 涨, 0 跌
            BigDecimal rate = order.getRate();
            BigDecimal openPrice = order.getOpenPrice();
            Integer sign = order.getSign();
            String coinSymbol = order.getCoinSymbol();
            Integer isVirtual = order.getIsVirtual() != null ? order.getIsVirtual() : 0; // 是否虚拟订单

            // 获取初始市场价格（仅参考，最终由 getClosePrice 调整）
            BigDecimal newPrice = redisCache.getCacheObject(CachePrefix.CURRENCY_PRICE.getPrefix() + coinSymbol);
            TSecondCoinConfig one = secondCoinConfigService.getOne(new LambdaQueryWrapper<TSecondCoinConfig>().eq(TSecondCoinConfig::getCoin, coinSymbol));
            if (one != null && 2 != one.getType()) {
                newPrice = redisCache.getCacheObject(CachePrefix.CURRENCY_PRICE.getPrefix() + coinSymbol.toUpperCase());
            }

            // 计算收盘价
            newPrice = getClosePrice(openPrice, newPrice, sign, type);

            TAppUserDetail tAppUserDetail = appUserDetailService.getOne(new LambdaQueryWrapper<TAppUserDetail>().eq(TAppUserDetail::getUserId, tAppUser.getUserId()));
            int winNum = tAppUserDetail.getWinNum() == null ? 0 : tAppUserDetail.getWinNum();
            int loseNum = tAppUserDetail.getLoseNum() == null ? 0 : tAppUserDetail.getLoseNum();
            Integer buff = tAppUser.getBuff();

            // 连赢/连输调整
            if (buff == 0 && sign == 0) {
                if (winNum > 0) {
                    tAppUserDetail.setWinNum(winNum - 1);
                    appUserDetailService.updateById(tAppUserDetail);
                    newPrice = getClosePrice(openPrice, newPrice, 1, type); // 强制包赢
                    sign = 1;
                } else if (loseNum > 0) {
                    tAppUserDetail.setLoseNum(loseNum - 1);
                    appUserDetailService.updateById(tAppUserDetail);
                    newPrice = getClosePrice(openPrice, newPrice, 2, type); // 强制包输
                    sign = 2;
                }
            }

            // 用户 buff 调整
            if (buff == 1) {
                sign = 1;
                newPrice = getClosePrice(openPrice, newPrice, 1, type); // 包赢
            } else if (buff == 2) {
                sign = 2;
                newPrice = getClosePrice(openPrice, newPrice, 2, type); // 包输
            }

            // 输赢判断
            if (CommonEnum.TRUE.getCode().equals(type)) {
                // 买涨
                if (openPrice.compareTo(newPrice) > 0) {
                    openResult = "2"; // 输
                    if (rate.compareTo(BigDecimal.ONE) < 0) {
                        returnAmount = betAmount.multiply(BigDecimal.ONE.subtract(rate));
                    } else {
                        returnAmount = BigDecimal.ZERO;
                    }
                    if (null != order.getRateFlag() && order.getRateFlag()) {
                        returnAmount = BigDecimal.ZERO;
                    }
                } else if (openPrice.compareTo(newPrice) < 0) {
                    // 赢
                    if (rate.compareTo(BigDecimal.ONE) < 0) {
                        returnAmount = betAmount.multiply(BigDecimal.ONE.add(rate));
                    } else {
                        returnAmount = betAmount.add(betAmount.multiply(rate));
                    }
                } else {
                    openResult = "3"; // 平
                    returnAmount = betAmount;
                }
            } else {
                // 买跌
                if (openPrice.compareTo(newPrice) > 0) {
                    // 赢
                    if (rate.compareTo(BigDecimal.ONE) < 0) {
                        returnAmount = betAmount.multiply(BigDecimal.ONE.add(rate));
                    } else {
                        returnAmount = betAmount.add(betAmount.multiply(rate));
                    }
                } else if (openPrice.compareTo(newPrice) < 0) {
                    openResult = "2"; // 输
                    if (rate.compareTo(BigDecimal.ONE) < 0) {
                        returnAmount = betAmount.multiply(BigDecimal.ONE.subtract(rate));
                    } else {
                        returnAmount = BigDecimal.ZERO;
                    }
                    if (null != order.getRateFlag() && order.getRateFlag()) {
                        returnAmount = BigDecimal.ZERO;
                    }
                } else {
                    openResult = "3"; // 平
                    returnAmount = betAmount;
                }
            }

            // 根据订单类型更新资产
            if (isVirtual == 1) {
                // 虚拟订单：更新 virtualCoin
                if (returnAmount.compareTo(BigDecimal.ZERO) > 0) {
                    BigDecimal currentVirtualCoin = tAppUser.getVirtualCoin() != null ? tAppUser.getVirtualCoin() : BigDecimal.ZERO;
                    tAppUser.setVirtualCoin(currentVirtualCoin.add(returnAmount));
                    appUserService.updateTAppUser(tAppUser);
                    // 生成虚拟订单结算记录
                    appWalletRecordService.generateRecord(
                            order.getUserId(),
                            returnAmount,
                            RecordEnum.OPTION_SETTLEMENT.getCode(),
                            "",
                            order.getOrderNo(),
                            "Virtual Option Settlement",
                            currentVirtualCoin,
                            currentVirtualCoin.add(returnAmount),
                            order.getBaseSymbol(),
                            tAppUser.getAdminParentIds()
                    );
                }
            } else {
                // 真实订单：更新 TAppAsset
                if (returnAmount.compareTo(BigDecimal.ZERO) > 0) {
                    Map<String, TAppAsset> assetByUserIdList = assetService.getAssetByUserIdList(order.getUserId());
                    TAppAsset appAsset = assetByUserIdList.get(order.getBaseSymbol() + order.getUserId());
                    BigDecimal availableAmount = appAsset.getAvailableAmount();
                    appAsset.setAmout(appAsset.getAmout().add(returnAmount));
                    appAsset.setAvailableAmount(availableAmount.add(returnAmount));
                    assetService.updateTAppAsset(appAsset);
                    appWalletRecordService.generateRecord(
                            order.getUserId(),
                            returnAmount,
                            RecordEnum.OPTION_SETTLEMENT.getCode(),
                            "",
                            order.getOrderNo(),
                            RecordEnum.OPTION_SETTLEMENT.getInfo(),
                            availableAmount,
                            availableAmount.add(returnAmount),
                            order.getBaseSymbol(),
                            tAppUser.getAdminParentIds()
                    );
                }
            }

            // 更新订单状态
            order.setOpenResult(openResult);
            order.setClosePrice(newPrice);
            order.setStatus(1);
            order.setRewardAmount(returnAmount);
            order.setSign(sign);
            secondContractOrderService.updateById(order);

            // 推送结算事件
            HashMap<String, Object> object = new HashMap<>();
            object.put("settlement", "3");
            redisUtil.addStream(redisStreamNames, object);
        } catch (Exception e) {
            log.error("订单结算异常, orderId: {}", order.getId(), e);
        }
    }

    /**
     * 计算收盘价，所有订单基于 openPrice 加减 diff
     * 如果 openPrice > 1000，则 diff 为 5.00-20.99 的随机小数
     * 否则使用原有小数位逻辑
     * @param openPrice 开盘价
     * @param closePrice 原收盘价（仅参考）
     * @param sign 订单标记 0正常 1包赢 2包输
     * @param type 跌涨 1涨 0跌
     * @return 调整后的收盘价
     */
    public static BigDecimal getClosePrice(BigDecimal openPrice, BigDecimal closePrice, Integer sign, Integer type) {
        // 计算 diff
        BigDecimal diff;
        if (openPrice.compareTo(new BigDecimal("1000")) > 0) {
            // 价格 > 1000，diff 为 5.00-20.99 之间的随机小数
            double randomDiff = ThreadLocalRandom.current().nextDouble(5.00, 21.00); // 5.00 到 20.99
            diff = new BigDecimal(String.valueOf(randomDiff)).setScale(2, RoundingMode.HALF_UP);
        } else {
            // 价格 <= 1000，使用原有小数位逻辑
            int digits = getNumberDecimalDigits(openPrice.stripTrailingZeros().toPlainString());
            if (digits == 0) {
                diff = BigDecimal.valueOf(ThreadLocalRandom.current().nextDouble()); // 0-1
            } else {
                diff = BigDecimal.valueOf((double) 1 / Math.pow(10, digits) * (ThreadLocalRandom.current().nextInt(10) + 1));
            }
        }

        // 根据 sign 和 type 调整价格
        if (sign == 1) { // 包赢
            if (1 == type) { // 买涨
                closePrice = openPrice.add(diff); // 涨
            } else if (0 == type) { // 买跌
                closePrice = openPrice.subtract(diff); // 跌
            }
        } else if (sign == 2) { // 包输
            if (1 == type) { // 买涨
                closePrice = openPrice.subtract(diff); // 跌
            } else if (0 == type) { // 买跌
                closePrice = openPrice.add(diff); // 涨
            }
        } else { // sign == 0，正常订单
            // 随机涨跌
            boolean randomDirection = ThreadLocalRandom.current().nextBoolean();
            if (randomDirection) {
                closePrice = openPrice.add(diff); // 随机涨
            } else {
                closePrice = openPrice.subtract(diff); // 随机跌
            }
        }

        return closePrice;
    }

    // 获取小数位个数
    public static int getNumberDecimalDigits(String number) {
        if (!number.contains(".")) {
            return 0;
        }
        return number.length() - (number.indexOf(".") + 1);
    }
}