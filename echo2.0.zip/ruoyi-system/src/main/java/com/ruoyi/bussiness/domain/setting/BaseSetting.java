package com.ruoyi.bussiness.domain.setting;

import lombok.Data;

/**
 * 系统基本配置
 */
@Data
public class BaseSetting {
}
