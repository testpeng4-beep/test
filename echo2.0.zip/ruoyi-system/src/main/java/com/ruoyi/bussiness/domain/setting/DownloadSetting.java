package com.ruoyi.bussiness.domain.setting;

import lombok.Data;

@Data
public class DownloadSetting {
    private String name;
    private String url;
    private String sort;
    private String isOpen;

}
