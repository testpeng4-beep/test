package com.ruoyi.bussiness.domain.setting;

import lombok.Data;

/**
 * logo配置
 */
@Data
public class LogoSetting {
    private String logo;
    private String logoA;
    private String logoB;
    private String logoC;
    private String logoD;
}
