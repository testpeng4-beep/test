package com.ruoyi.bussiness.domain.setting;

import lombok.Data;

/**
 * 平台设置
 */
@Data
public class PlatformSetting {
    private String timezone;
    private boolean googleAuth;
}
