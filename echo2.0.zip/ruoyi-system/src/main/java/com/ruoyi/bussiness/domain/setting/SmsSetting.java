package com.ruoyi.bussiness.domain.setting;

import lombok.Data;

/**
 * 短信配置
 */
@Data
public class SmsSetting {


    private String name;//=node
    private String mobileAccount;//=I003662
    private String mobilePassword;//=OEwXRLHZkB23
    private String mobileUrl;//=https://api.nodesms.com/send/json

}
