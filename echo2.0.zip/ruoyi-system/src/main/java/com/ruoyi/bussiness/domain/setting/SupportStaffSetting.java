package com.ruoyi.bussiness.domain.setting;

import lombok.Data;

/**
 * 客服设置
 */
@Data
public class SupportStaffSetting {
    private String name;    //客服名称
    private String url;
    private String imgUrl;
}
