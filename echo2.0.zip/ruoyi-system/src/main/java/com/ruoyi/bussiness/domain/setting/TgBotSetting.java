package com.ruoyi.bussiness.domain.setting;

import lombok.Data;

@Data
public class TgBotSetting {

    private String botName;
    private String botToken;
    private String chatId;
}
