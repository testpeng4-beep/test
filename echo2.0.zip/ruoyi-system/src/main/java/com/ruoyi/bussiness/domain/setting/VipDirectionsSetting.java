package com.ruoyi.bussiness.domain.setting;


import lombok.Data;

@Data
public class VipDirectionsSetting {

    /**
     * 语言
     */
    private  String lang;

    /**
     * 详细信息
     */
    private String info;
}
