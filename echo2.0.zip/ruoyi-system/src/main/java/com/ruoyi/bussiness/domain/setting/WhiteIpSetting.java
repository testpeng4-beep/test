package com.ruoyi.bussiness.domain.setting;

import lombok.Data;

/**
 * 后台ip控制
 */
@Data
public class WhiteIpSetting {
    private String ip;
    private String remark;
}
