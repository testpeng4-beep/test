package com.ruoyi.bussiness.domain.setting;

import lombok.Data;

@Data
public class WhitePaperSetting {
    private String url;
}
