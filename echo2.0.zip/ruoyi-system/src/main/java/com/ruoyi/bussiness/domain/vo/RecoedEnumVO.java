package com.ruoyi.bussiness.domain.vo;

import lombok.Data;

@Data
public class RecoedEnumVO {

    private Integer key;
    private String value;
}
