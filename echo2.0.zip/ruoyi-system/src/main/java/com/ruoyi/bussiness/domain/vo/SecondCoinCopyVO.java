package com.ruoyi.bussiness.domain.vo;

import lombok.Data;

@Data
public class SecondCoinCopyVO {
    private Long copyId;
    private Long[] copyIds;
}
