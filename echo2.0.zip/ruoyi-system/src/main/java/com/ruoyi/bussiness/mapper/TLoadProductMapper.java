package com.ruoyi.bussiness.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import java.util.List;
import com.ruoyi.bussiness.domain.TLoadProduct;

/**
 * 借贷产品Mapper接口
 * 
 * @author ruoyi
 * @date 2023-07-13
 */
public interface TLoadProductMapper extends BaseMapper<TLoadProduct>
{
    /**
     * 查询借贷产品
     * 
     * @param id 借贷产品主键
     * @return 借贷产品
     */
    TLoadProduct selectTLoadProductById(Long id);

    /**
     * 查询借贷产品列表
     * 
     * @param tLoadProduct 借贷产品
     * @return 借贷产品集合
     */
    List<TLoadProduct> selectTLoadProductList(TLoadProduct tLoadProduct);

    /**
     * 新增借贷产品
     * 
     * @param tLoadProduct 借贷产品
     * @return 结果
     */
    int insertTLoadProduct(TLoadProduct tLoadProduct);

    /**
     * 修改借贷产品
     * 
     * @param tLoadProduct 借贷产品
     * @return 结果
     */
    int updateTLoadProduct(TLoadProduct tLoadProduct);

    /**
     * 删除借贷产品
     * 
     * @param id 借贷产品主键
     * @return 结果
     */
    int deleteTLoadProductById(Long id);

    /**
     * 批量删除借贷产品
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    int deleteTLoadProductByIds(Long[] ids);
}
